# credit_semaphore
Asynchronous Semaphore Based on Credits for Efficient Credit-Based API Throttling
